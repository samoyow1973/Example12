#include "Object.h"

extern VERTEX* Triangle;
extern unsigned long * Indices;
extern INSTANCE* Instance;
extern UINT count_vertex;
extern UINT count_indices;
VOID CreateSphere(UINT count)
{
    UINT A = UINT(sqrt(count));
    UINT B = UINT(sqrt(count) / 2);
    Triangle = new VERTEX[(A + 1) * (B + 1)];
    Indices = new unsigned long[A * B * 2 * 3];
    count_vertex = (A + 1) * (B + 1);
    count_indices = A * B * 2 * 3;
    //���������� ������� ������, ����. �����.
    //� ������� ��� ����������� ��������� ��� �� ������
    for (UINT i = 0; i < B + 1; i++)
        for (UINT j = 0; j < A + 1; j++)
        {
            Triangle[i * (A + 1) + j].pos =
                XMFLOAT3(cos(XM_PI * j * 2.0f / A) * sin(XM_PI / B * i),
                    cos(XM_PI / B * i),
                    sin(XM_PI * j * 2.0f / A) * sin(XM_PI / B * i));
            if (j == A) Triangle[i * (A + 1) + j].pos = Triangle[i * (A + 1)].pos;
            Triangle[i * (A + 1) + j].normal = Triangle[i * (A + 1) + j].pos;
           
        }
    //������ ��������
    for (UINT i = 0; i < B; i++)
        for (UINT j = 0; j < A; j++)
        {
            Indices[(i * A + j) * 6] = i * (A + 1) + j;
            Indices[(i * A + j) * 6 + 1] = (i + 1) * (A + 1) + j;
            Indices[(i * A + j) * 6 + 2] = (i + 1) * (A + 1) + j + 1;
            Indices[(i * A + j) * 6 + 3] = (i + 1) * (A + 1) + j + 1;
            Indices[(i * A + j) * 6 + 4] = i * (A + 1) + j + 1;
            Indices[(i * A + j) * 6 + 5] = i * (A + 1) + j;
        }
}
VOID CreateInstance(UINT count)
{
    srand(GetTickCount());
    Instance = new INSTANCE[count];
    for (UINT i = 0; i < count; i++)
    {
        float r = float(rand() % 100) * 0.0005f;
        XMMATRIX ms= XMMatrixScaling(r, r, r);
        
        float tx = float(rand() % 1000) * 0.002f - 1.0f;
        float ty = float(rand() % 1000) * 0.002f - 1.0f;
        float tz = float(rand() % 1000) * 0.002f - 1.0f;
        XMMATRIX mt=XMMatrixTranslation(tx,ty,tz);
            
        
        Instance[i].mat = XMMatrixMultiply(ms, mt);
        Instance[i].color = XMFLOAT4(float(rand()%255)/255.0f, float(rand() % 255) / 255.0f, float(rand() % 255) / 255.0f, 1.0f);
    }
}