#pragma once
#ifndef OBJECT_H
#define OBJECT_H
#include "D3D.h"
VOID CreateSphere(UINT);
VOID CreateInstance(UINT);
VOID CreateCubePoligon();

#endif